function g = sigmoid(z)
  g = 1 ./ (1 + e.^-z);
end