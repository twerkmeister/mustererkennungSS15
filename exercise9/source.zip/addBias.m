function biasAdded = addBias(v)
  % display("addBias")
  % display("====================================")
  % display("v")
  % display(v)
  biasAdded = [v 1];
  % display("biasAdded")
  % display(biasAdded)
  % display("====================================")
end